package com.ibrahimsaleh.surveyworks;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.DownloadListener;
import android.widget.Toast;
import java.io.OutputStream;
import java.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new FileBridge(), "AndroidFiles");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this, "تعذر فتح مدير الملفات", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    if (uri.getHost() != null && (uri.getHost().equals("ibrahimsaleh.netlify.app") || uri.getHost().endsWith("google.com") || uri.getHost().endsWith("openstreetmap.org") || uri.getHost().endsWith("arcgisonline.com"))) return false;
                    startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("(function(){if(!document.getElementById('sw-native-status')){var n=document.createElement('div');n.id='sw-native-status';n.style='position:fixed;z-index:2147483647;top:0;left:0;right:0;text-align:center;padding:4px;font:12px sans-serif;background:#fff4d6;color:#6b4d13;display:none';document.body.appendChild(n);}function s(){var x=document.getElementById('sw-native-status');if(x){x.style.display=navigator.onLine?'none':'block';x.textContent='وضع عدم الاتصال: بعض الخرائط والتحويلات الخارجية تحتاج إلى الإنترنت';}}window.addEventListener('online',s);window.addEventListener('offline',s);s();})();", null);
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception ignored) { Toast.makeText(this, "استخدم زر التنزيل داخل التطبيق أو شارك الملف", Toast.LENGTH_LONG).show(); }
        });
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private class FileBridge {
        @JavascriptInterface public void saveBase64(String filename, String mime, String data) {
            try {
                String clean = filename == null ? "SurveyWorks-file" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
                byte[] bytes;
                if (Build.VERSION.SDK_INT >= 26) bytes = Base64.getDecoder().decode(data);
                else bytes = android.util.Base64.decode(data, android.util.Base64.DEFAULT);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, clean);
                values.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri collection = Build.VERSION.SDK_INT >= 29 ? MediaStore.Downloads.EXTERNAL_CONTENT_URI : MediaStore.Files.getContentUri("external");
                Uri item = getContentResolver().insert(collection, values);
                if (item == null) throw new Exception("Could not create download");
                OutputStream out = getContentResolver().openOutputStream(item);
                out.write(bytes); out.close();
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(item, done, null, null);
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم حفظ الملف في التنزيلات", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تعذر حفظ الملف: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results); filePathCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
